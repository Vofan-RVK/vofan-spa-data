"""MCP server exposing one pinned GitHub repository as MCP tools.

Built for the Vofan poll-data pipeline: lets Vibe Work read and update
files in a single GitHub repo (chosen via environment variables) and
check its GitHub Action runs. The GitHub token never leaves this server.

Repository structure, transport security settings, ASGI bearer wrapper
and deployment follow the proven cloud-caldav-mcp pattern.
"""

from __future__ import annotations

import base64
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings

GITHUB_API = "https://api.github.com"
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
GITHUB_OWNER = os.environ.get("GITHUB_OWNER", "")
GITHUB_REPO = os.environ.get("GITHUB_REPO", "")

# Same rationale as cloud-caldav-mcp: this is a public, bearer-token-
# authenticated API behind Render's reverse proxy. The SDK's DNS
# rebinding Host/Origin checks reject the public onrender.com Host with
# 421; disabling them via the SDK's official transport_security setting
# is the documented configuration for a server behind a proxy. The ASGI
# wrapper below enforces the bearer token on every request.
mcp = FastMCP(
    "github-repo",
    transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
)


def _require_env() -> None:
    missing = [
        name
        for name, value in (
            ("GITHUB_TOKEN", GITHUB_TOKEN),
            ("GITHUB_OWNER", GITHUB_OWNER),
            ("GITHUB_REPO", GITHUB_REPO),
        )
        if not value
    ]
    if missing:
        raise RuntimeError(
            f"{' and '.join(missing)} must be set. GITHUB_TOKEN is a "
            "fine-grained PAT scoped to the single repository; GITHUB_OWNER "
            "and GITHUB_REPO pin which repository this server may touch."
        )


class GitHubApiError(RuntimeError):
    def __init__(self, status: int, method: str, endpoint: str, message: str):
        self.status = status
        super().__init__(f"GitHub API {status} on {method} {endpoint}: {message}")


def _gh_api(method: str, endpoint: str, body: dict[str, Any] | None = None) -> Any:
    """Call the GitHub REST API on the pinned repository."""
    _require_env()
    url = f"{GITHUB_API}{endpoint}"
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {GITHUB_TOKEN}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "github-repo-mcp",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        try:
            message = json.loads(detail).get("message", detail)
        except (json.JSONDecodeError, ValueError):
            message = detail
        raise GitHubApiError(exc.code, method, endpoint, message) from None


def _repo_path(prefix: str = "") -> str:
    return f"/repos/{GITHUB_OWNER}/{GITHUB_REPO}{prefix}"


def _clean_repo_path(path: str) -> str:
    """Validate and normalise a repo-relative file path."""
    cleaned = path.strip().strip("/")
    if not cleaned or ".." in cleaned.split("/") or cleaned.startswith("."):
        raise ValueError(f"Invalid repository path: {path!r}")
    return cleaned


def _decode_content(entry: dict[str, Any]) -> str:
    if entry.get("encoding") != "base64":
        raise RuntimeError(
            f"Cannot decode file {entry.get('path', '?')} "
            f"(encoding: {entry.get('encoding')})"
        )
    return base64.b64decode(entry["content"]).decode("utf-8")


@mcp.tool()
def get_file(path: str, ref: str = "") -> dict[str, Any]:
    """Read a file (or list a directory) from the repository.

    For a file path, returns {'path', 'sha', 'size', 'content'}.
    For a directory path, returns {'entries': [{name, path, type, sha}]}.
    ref is optional: a branch, tag or commit SHA.
    """
    cleaned = _clean_repo_path(path)
    query = f"?ref={urllib.parse.quote(ref)}" if ref else ""
    result = _gh_api("GET", f"{_repo_path('/contents/')}{urllib.parse.quote(cleaned, safe='/')}{query}")
    if isinstance(result, list):
        return {
            "entries": [
                {"name": e["name"], "path": e["path"], "type": e["type"], "sha": e["sha"]}
                for e in result
            ]
        }
    return {
        "path": result["path"],
        "sha": result["sha"],
        "size": result["size"],
        "content": _decode_content(result),
    }


@mcp.tool()
def put_file(path: str, content: str, message: str, branch: str = "") -> dict[str, Any]:
    """Create or update a single text file in the repository.

    The file's existing SHA is looked up automatically, so calling this
    on an existing file updates it in place. Returns the new commit.
    """
    cleaned = _clean_repo_path(path)
    if not message.strip():
        raise ValueError("A commit message is required")
    # Fail fast on invalid UTF-8 rather than committing garbage.
    encoded = content.encode("utf-8")

    sha: str | None = None
    try:
        existing = _gh_api(
            "GET", f"{_repo_path('/contents/')}{urllib.parse.quote(cleaned, safe='/')}"
        )
        if isinstance(existing, dict) and "sha" in existing:
            sha = existing["sha"]
    except GitHubApiError as exc:
        if exc.status != 404:
            raise
    body: dict[str, Any] = {
        "message": message,
        "content": base64.b64encode(encoded).decode("ascii"),
    }
    if sha:
        body["sha"] = sha
    if branch:
        body["branch"] = branch
    result = _gh_api("PUT", f"{_repo_path('/contents/')}{urllib.parse.quote(cleaned, safe='/')}", body)
    commit = result.get("commit", {})
    return {
        "status": "updated" if sha else "created",
        "path": cleaned,
        "commit_sha": commit.get("sha"),
        "commit_url": commit.get("html_url"),
        "message": message,
    }


@mcp.tool()
def list_commits(path: str = "", limit: int = 5) -> list[dict[str, Any]]:
    """List the repository's recent commits, newest first.

    path filters to commits touching that file. limit is capped at 50.
    """
    limit = max(1, min(int(limit), 50))
    query = f"?per_page={limit}"
    if path:
        query += f"&path={urllib.parse.quote(_clean_repo_path(path), safe='/')}"
    commits = _gh_api("GET", f"{_repo_path('/commits')}{query}")
    return [
        {
            "sha": c["sha"],
            "message": c["commit"]["message"].splitlines()[0],
            "author": c["commit"]["author"]["name"],
            "date": c["commit"]["author"]["date"],
            "url": c.get("html_url"),
        }
        for c in commits
    ]


@mcp.tool()
def get_action_runs(limit: int = 5) -> list[dict[str, Any]]:
    """List recent GitHub Actions runs (name, status, conclusion, url).

    limit is capped at 50. Use this to check whether the repository's
    publish workflow succeeded after a push.
    """
    limit = max(1, min(int(limit), 50))
    data = _gh_api("GET", f"{_repo_path('/actions/runs')}?per_page={limit}")
    return [
        {
            "name": run["name"],
            "status": run["status"],
            "conclusion": run.get("conclusion"),
            "created_at": run["created_at"],
            "url": run["html_url"],
        }
        for run in data.get("workflow_runs", [])
    ]


CORS_HEADERS = [
    (b"access-control-allow-origin", b"*"),
    (b"access-control-allow-headers",
     b"Authorization, Content-Type, Accept, Mcp-Session-Id, Mcp-Protocol-Version"),
    (b"access-control-allow-methods", b"GET, POST, DELETE, OPTIONS"),
]


def _asgi_wrapper(app: Any) -> Any:
    """Wrap the MCP app with bearer auth, probes, CORS and host fixes."""
    token = os.environ.get("MCP_BEARER_TOKEN", "")

    async def _reply(send: Any, status: int, body: bytes, extra: list) -> None:
        headers = CORS_HEADERS + list(extra)
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": headers,
            }
        )
        await send({"type": "http.response.body", "body": body})

    async def wrapped(scope: dict, receive: Any, send: Any) -> None:
        if scope.get("type") != "http":
            await app(scope, receive, send)
            return
        headers = {
            k.decode("latin-1").lower(): v.decode("latin-1")
            for k, v in scope.get("headers", [])
        }
        if scope.get("method") == "OPTIONS":
            await _reply(send, 204, b'{"status":"preflight"}', [])
            return
        path = scope.get("path", "")
        if path.startswith("/.well-known/"):
            await _reply(send, 404, b'{"error":"not found"}', [])
            return
        if token:
            if headers.get("authorization") != f"Bearer {token}":
                await _reply(
                    send, 401, b'{"error":"unauthorized"}', [(b"www-authenticate", b"Bearer")]
                )
                return
        if scope.get("method") in ("GET", "HEAD") and "mcp-session-id" not in headers:
            await _reply(send, 200, b'{"status":"ok"}', [])
            return

        async def send_with_cors(message: dict) -> None:
            if message.get("type") == "http.response.start":
                message = dict(message)
                message["headers"] = list(message.get("headers", [])) + CORS_HEADERS
            await send(message)

        await app(scope, receive, send_with_cors)

    return wrapped


def main() -> None:
    """Run the server over Streamable HTTP (the transport Work expects)."""
    host = os.environ.get("MCP_HOST", "0.0.0.0")
    port = int(os.environ.get("PORT") or os.environ.get("MCP_PORT", "8000"))
    app = mcp.streamable_http_app()
    import uvicorn

    uvicorn.run(_asgi_wrapper(app), host=host, port=port)


if __name__ == "__main__":
    main()
