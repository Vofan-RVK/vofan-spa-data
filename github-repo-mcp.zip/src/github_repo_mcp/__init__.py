"""github-repo-mcp: one pinned repository, four tools."""
