# github-repo-mcp

A tiny MCP server that exposes **one GitHub repository** (chosen by
environment variables) as four tools for Vibe Work:

| Tool | What it does |
|---|---|
| `get_file` | Read a file (or list a directory) in the repository |
| `put_file` | Create or update a single text file (auto-handles the existing SHA) |
| `list_commits` | Recent commits, optionally filtered by path |
| `get_action_runs` | Recent GitHub Actions runs with status and conclusion |

Built for the Vofan poll-data pipeline (`vofan-spa-data`), where the
update loop is: a poll file is committed via `put_file`, the repo's
"Reikna spá" action recomputes `public/forecast.json`, and
`get_action_runs` confirms it succeeded.

## Security model

- **Repository pinning.** `GITHUB_OWNER` and `GITHUB_REPO` come from the
  environment; no tool takes an owner or repository argument. The server
  cannot be pointed at any other repository, whatever a request says.
- **Single-repo token.** `GITHUB_TOKEN` is a fine-grained personal access
  token scoped to exactly one repository (Contents: Read and write,
  Actions: Read). Worst case if it ever leaks: someone can edit the
  public poll data in that one repo.
- **Bearer gate.** `MCP_BEARER_TOKEN` is required on every HTTP request
  (ASGI wrapper, same as cloud-caldav-mcp).
- Credentials live only in Render environment variables — never in this
  repo, in chat, or in Knowledge.

## Setup

### 1. Fine-grained PAT (on the GitHub account that owns the data repo)

GitHub → Settings → Developer settings → Fine-grained tokens →
Generate new token:

- Repository access: **Only select repositories** → the data repo
  (e.g. `vofan-spa-data`)
- Permissions: **Contents: Read and write**, **Actions: Read**
- Set an expiry (e.g. 90 days) and note the date to rotate it; updating
  the `GITHUB_TOKEN` env var on Render redeploys with the new token.

### 2. Deploy on Render

New Web Service from this repo (runtime: Docker), or use `render.yaml`.
Env vars:

| Key | Value |
|---|---|
| `GITHUB_TOKEN` | the fine-grained PAT |
| `GITHUB_OWNER` | the pen-named account, e.g. `Vofan-RVK` |
| `GITHUB_REPO` | e.g. `vofan-spa-data` |
| `MCP_BEARER_TOKEN` | `openssl rand -hex 32` |

Service name suggestion: `github-repo-mcp` →
`https://github-repo-mcp.onrender.com/mcp`.

Free tier sleeps after ~15 min idle: the first request after a nap is
slow (cold start), which is fine for a poll-data server used every few
weeks. No uptime pinger needed.

### 3. Connect in Vibe Work

Context → Connectors → Add connector → custom MCP:

- URL: `https://github-repo-mcp.onrender.com/mcp`
- Header: `Authorization: Bearer <the MCP_BEARER_TOKEN>`

Recommended function permissions (same policy as cloud-caldav-mcp's
write tools): keep `put_file` on **manual approval**; pre-authorize the
read-only tools (`get_file`, `list_commits`, `get_action_runs`).

## Local development

```bash
pip install -e .
GITHUB_TOKEN=... GITHUB_OWNER=... GITHUB_REPO=... \
MCP_BEARER_TOKEN=... python -m github_repo_mcp.server
```
